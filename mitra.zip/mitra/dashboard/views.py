from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.contrib.auth import login, logout, authenticate
from .forms import userForm


def home(request):
    return render(request, 'home/home.html')


def signupuser(request):
    if request.method == 'GET':
        return render(request,'signup/signupuser.html', {'form':userForm()})
    else:
        if request.POST['password1'] == request.POST['password2']:
            try:
                user = User.objects.create_user(request.POST['username'], request.POST['email'], password = request.POST['password1'],first_name = request.POST['first_name'],last_name = request.POST['last_name'])
                user.save()
                login(request,user)
                return redirect('index')
            except IntegrityError:
                  return render(request,'signup/signupuser.html',{'form':userForm(), 'error':"Password or Usernamr doesn't match"})

        else:
            return render(request,'signup/signupuser.html',{'form':userForm(), 'error':"Password doesn't match"} )


def loginuser(request):
    if request.method == 'GET':
        return render(request,'signup/loginuser.html', {'form':AuthenticationForm( )})
    else:
        user = authenticate(request,username=request.POST['username'], password=request.POST['password'])
        if user is None:
                return render(request,'signup/loginuser.html', {'form':AuthenticationForm( )} , {'error': "Username,password doesn't match"})
        elif user.username is "Sumit":
            #login(request, user)
            return redirect('admin')
        else:
            login(request, user)
            return redirect('index')


def logoutuser(request):
    #if request.method == 'POST':
            logout(request)
            return redirect('home')

def currenttodo(request):
    return render(request,'signup/currenttodo.html')

def index(request):
    return render(request,'dashboard/index3.html')
